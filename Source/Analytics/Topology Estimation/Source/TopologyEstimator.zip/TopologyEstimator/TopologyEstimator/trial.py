import numpy as np, pdb, psspy
from Bus_Connections import bus_connections
from configuration import Configuration
from Update_Network import update_network
def pass_on(select):

    bus_matrix = psspy.abusint(-1, 1, ['NUMBER', 'type', 'area', 'zone', 'owner'])
    bus_nums = bus_matrix[1][0]
    Max_initial_busnum=max(bus_nums)
    cases_below = 0
    cases_up = 0
    actual_total_cases = 0
    # initializing the variables for plotting
    Y_vector1_Ang = []
    Y_vector2_Ang = []
    Y_vector1_Mag = []
    Y_vector2_Mag = []
    ind1 = 0
    ind2 = 0
    Y_vector_temp_Ang = []
    Y_vector_temp_Mag = []
    # Y_vector=zeros(0,0)

    out_of_bound = 0  # to know number of diverging cases
    total_cases = 0  # to know total number of cases
    slack = 0
    divergent_cases = []
    indication = []

    #for select in range(1,Max_initial_busnum+1):
    #select=13
    # Creating different scenarios for contingencies related to the selected Bus(substation)
    # #############################################################################################################

    # To know what circuits are connected as well its number
    # -------------------------------------------------------------------------
    num_connec, circ = bus_connections(select)  # Call"bus_connections" to get the total number of circuits at the selected bus.


    # Calling configuration for knowing all the possible configurations of outages adjacent to the substation
    configuration_matrix = Configuration(num_connec)

    # 1-Connected to original Bus
    # Any other number-Disconnected from original Bus
    # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    # Running Load flow analysis for each possible num_connec



    for i in range(len(configuration_matrix)):
        indicator1 = 0
        indicator2 = 0
        outage_buses = []
        outage_groups = []
        status_provided = configuration_matrix[i]
        #status_provided =[1,1,0]
        for m in range(num_connec):
            if status_provided[m] != 1:
                outage_buses.append(circ[m])# to get only those buses which are disconnected to find how
                outage_groups .append(status_provided[m])  # many extra buses to be introduced along with their grouping numbers

        outage_matrix =[outage_buses]+[outage_groups]

        if len(outage_buses) != 0:  # to check if any actual contingencies have talen place or everything is the same.
                    index_temp2 = len(outage_buses)

                    extra = update_network(select,outage_matrix)  # Call"Network_updated.m" to get the modified arrangement.

                    # if the original bus is being tried to be removed
                    if (status_provided[num_connec-1] == 1 and index_temp2 >= (num_connec - 1)) or (status_provided[num_connec-1] == 0 and index_temp2 == num_connec):
                        print('Gen or load at the present bus is getting disconnected from the system')
                        if select != 1:
                            print('No problem')

                        else:
                            print('Access to remove Slack bus denied')
                    psspy.fnsl()
                    total_cases = total_cases + 1
                    #out_of_bound = out_of_bound + diverge

                    # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    # Checking for Delta coherency and Angle Mismatch vector
                    temp1 = sorted(zip(outage_matrix[1], outage_matrix[0]))
                    temp2 = [list(t) for t in zip(*temp1)]
                    outage_buses_sort= temp2[1]
                    outage_groups_sort= temp2[0]

                    bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angled'])
                    bus_bases = bus_volt_matrix[1][0]
                    V = bus_volt_matrix[1][1]
                    Delta = bus_volt_matrix[1][2]    #in degrees


                    if extra != 0:        # to proceed calculation we need to know if there were any new extra buses created or not
                        Diff_Ang = []
                        Difference_Ang = 0
                        Diff_Mag = []
                        Difference_Mag = 0

                        for i in range(extra):

                            if (outage_buses_sort[i] != select) or (outage_buses_sort[i] != 100000):          #because this means no new buses were created hence no difference to be calculated
                                temp1 = select
                                # temp2=outage_buses_sort(i);
                                if outage_groups_sort[i] != 0:
                                    temp2 = Max_initial_busnum + extra -(max(outage_groups_sort) - outage_groups_sort[i])  # problem lies here   t1=num+extra-(max(outage_group)-outage_group(o));
                                else:
                                    temp2 = Max_initial_busnum + i+1

                                Difference_Ang = abs(Delta[temp1-1] - Delta[temp2-1])
                                Difference_Mag = abs(V[temp1-1] - V[temp2-1])
                                if (Difference_Ang >= 1 and Difference_Ang <= 90) :  # &&
                                    print('Bus ', outage_buses_sort[i],' and ', select,' are disconnected')

                                Diff_Ang.append(Difference_Ang)
                                Diff_Mag.append(Difference_Mag)

                        for i in range(len(Diff_Ang)):
                            if (Diff_Ang[i] >= 1 and Diff_Ang[i] <= 90) or Diff_Mag[i]>0.005:
                                print('Bus ', outage_buses_sort[i], ' and ', select, ' are disconnected')

                                Y_vector1_Ang.append(Diff_Ang[i])
                                Y_vector1_Mag.append(Diff_Mag[i])
                                if indicator2 != 1:
                                    indicator1 = 1

                                elif (Diff_Ang[i] < 1 and Diff_Ang[i] > 0 and V[select-1] != 0) and (Diff_Mag[i] < 0.005 and Diff_Mag[i] > 0):  # As it will be outliers but on the contrary it should not be
                                    Y_vector2_Ang.append(Diff_Ang[i])
                                    Y_vector2_Mag.append( Diff_Mag[i])
                                    indicator2 = 1
                                    indicator1 = 0
                                    indication.extend(select)

        else:
                print('Normal Load Flow and no disconnection')

        if indicator1 == 1:
            cases_up = cases_up + 1

        if indicator2 == 1:
            cases_below = cases_below + 1
            actual_total_cases = cases_up + cases_below

    pdb.set_trace()


    return extra
