#---------------------------------------------------------------------------------------------------------------------
#temp=truth_table(n)
# Version 1.0(Alpha)
# Last Modified: 11/8/2016

#The purpose of this function is to create a Truth table consisting of 0's and 1's which will be used in the
# configuration function later.This provides the possible number of configurations based on the the variable n in
# a list format consisting of 2^n elements inside the final temp list.

#Input:
    # n :which denotes the variable for which the truth table is to be generated.
#Output:
    #temp:A list of all 2^n elements which represents the truth table associated with variable n.
#----------------------------------------------------------------------------------------------------------------------
def truth_table(n):
    if n < 1:
        temp= [[]]
        return temp
    subtable = truth_table(n - 1)                               #recursively call the truth_table function
    temp= [row + [v] for row in subtable for v in [1, 0]]       #start filling [1 ,0] as necessary
    return temp
