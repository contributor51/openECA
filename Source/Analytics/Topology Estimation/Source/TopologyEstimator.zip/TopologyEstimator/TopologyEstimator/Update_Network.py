#-----------------------------------------------------------------------------
# extra = update_network(curr_bus_num, outage_matrix)
# Version 1.0(Alpha)
# Last Modified: 11/8/2016

# This function modifies the current system depending on the current outage scenario
# given to the function. Outage_matrix provides the current connection list of the
# buses surrounding the current bus to the current bus and between each other. The
# network is updated so that each bus within the same outage group is connected to each other
# through a newly created bus. Any bus is outage group 0 is connected to a newly created bus.
# Branches connecting the current bus and the buses connected to this bus that are in the outage_group
# are taken out of service and new branches are created connected the outside buses and the newly created
# buses.

#Inputs:
    # curr_bus_num: The bus for which the connection list is desired
    # outage_matrix: contains two lists, one containing all of the buses that our out
        # and the other containing their associated outage group
        # e.g. outage_matrix = [[1,2,3,4,5],[2,0,0,2,0]]

#Outputs:
    # extra: The number of additional buses created
#-----------------------------------------------------------------------------

import numpy as np,pdb,psspy

def update_network(curr_bus_num,outage_matrix):

    # This portion of code is used to read all of the values from the current system
    # that will be needed to modify the system

    # creates a list of all buses
    bus_matrix=psspy.abusint(-1,1,['NUMBER','type','area','zone','owner'])
    bus_nums=bus_matrix[1][0]
    bus_types=bus_matrix[1][1]
    bus_areas=bus_matrix[1][2]
    bus_zones=bus_matrix[1][3]
    bus_owners=bus_matrix[1][4]
    bus_volt_matrix=psspy.abusreal(-1,1,['base','pu','angle'])
    bus_bases=bus_volt_matrix[1][0]
    bus_volts = bus_volt_matrix[1][1]
    bus_angs = bus_volt_matrix[1][2]

    #branch data
    branch_matrix=psspy.abrnreal(-1, 1, 1, 2, 1, ['length', 'charging'])
    line_lengths=branch_matrix[1][0]
    line_charging=branch_matrix[1][1]
    rx_line=psspy.abrncplx(-1,1,1,2,1,'rx')
    line_r=np.real(rx_line[1][0])
    line_x=np.imag(rx_line[1][0])

    #tx data
    tx_matrix=psspy.atrnreal(-1,1,1,1,1,['ratea','rateb','ratec','nomv1','nomv2','sbase1','ratio','ratio2'])
    tx_ratea=tx_matrix[1][0]
    tx_rateb=tx_matrix[1][1]
    tx_ratec=tx_matrix[1][2]
    tx_nomv1=tx_matrix[1][3]
    tx_nomv2=tx_matrix[1][4]
    tx_sbase1=tx_matrix[1][5]
    tx_ratio1=tx_matrix[1][6]
    tx_ratio2=tx_matrix[1][7]
    rx_tx=psspy.atrncplx(-1,1,1,1,1,'rxact')
    tx_r=np.real(rx_tx[1][0])
    tx_x=np.imag(rx_tx[1][0])

    # get plant
    plant_matrix=psspy.agenbusint(-1,1,['number','ireg'])
    plant_nums=plant_matrix[1][0]
    plant_ireg=plant_matrix[1][1]

    gen_bus=psspy.agenbusreal(-1,1,['vspu','rmpct'])
    plant_vs=gen_bus[1][0]
    plant_rmpct=gen_bus[1][1]

    # get generator data
    machint=psspy.amachint(-1,4,['number','status'])
    gen_nums=machint[1][0]
    if curr_bus_num in gen_nums:
        index =gen_nums.index(curr_bus_num)
    gen_status=machint[1][1]

    mach_matrix=psspy.amachreal(-1,4,['mbase','pgen','qgen','pmax','pmin','qmax','qmin'])
    gen_bases=mach_matrix[1][0]
    gen_pg=mach_matrix[1][1]
    gen_qg=mach_matrix[1][2]
    gen_pmax=mach_matrix[1][3]
    gen_pmin=mach_matrix[1][4]
    gen_qmax=mach_matrix[1][5]
    gen_qmin=mach_matrix[1][6]

    rx_gen=psspy.amachcplx(-1,4,'zsorce')
    gen_zr=np.real(rx_gen[1][0])
    gen_zx=np.imag(rx_gen[1][0])

    # get load data
    load_matrix=psspy.aloadint(-1,4 ,['NUMBER','area','zone','owner','status','scale'])
    load_nums=load_matrix[1][0]
    if curr_bus_num in load_nums:
        index2 =load_nums.index(curr_bus_num)
    load_areas=load_matrix[1][1]
    load_zones=load_matrix[1][2]
    load_owners=load_matrix[1][3]
    load_status=load_matrix[1][4]
    load_scale=load_matrix[1][5]
    load_values=psspy.aloadcplx(-1,1,['mvaact','ilact','ylact'])
    load_p=np.real(load_values[1][0])
    load_q=np.imag(load_values[1][0])
    load_ip=np.real(load_values[1][1])
    load_iq = np.imag(load_values[1][1])
    load_yp = np.real(load_values[1][2])
    load_yq = np.imag(load_values[1][2])


    # creates a list of all source buses of lines(inlcudes xformers)
    temp = psspy.abrnint(-1, 1, 1, 1, 1, 'FromNUMBER')  # branches
    source_lines = temp[1][0]
    temp = psspy.abrnint(-1, 1, 1, 5, 1, 'FROMNUMBER')  # 2 winding xformer
    source_txes=temp[1][0]

    # creates a list of all destination buses of lines(inlcudes xformers)
    temp = psspy.abrnint(-1, 1, 1, 1, 1, 'ToNUMBER')  # branches
    dest_lines = temp[1][0]
    temp = psspy.abrnint(-1, 1, 1, 5, 1, 'ToNUMBER')  # 2 winding xformer
    dest_txes=temp[1][0]



    # All data required has been read, Algorithm starts here

    # defines initialization variables
    L_lines=len(source_lines) #number of lines
    L_txes=len(source_txes) #number of transformers
    high_bus_num=max(bus_nums) # finds the highest bus number

    #sorts outage_matrix into ascending order based on the group numbers
    temp1=sorted(zip(outage_matrix[1],outage_matrix[0]))
    temp2=[list(t) for t in zip(*temp1)]
    outage_buses = temp2[1]
    outage_group = temp2[0]
    numzeros=outage_group.count(0)#determines number of individual isolated buses in system

    # calculate total number of new buses that need to be created
    if max(outage_group)!=0:
        extra=max(outage_group) + numzeros - 1
    else:
        extra=numzeros
    total=len(outage_group)

    # generator and load connections/outages do not require a new bus but would still need
    # to be added to their outage group
    for i in range(total):
        if outage_group[i] == 0 and outage_buses[i] == curr_bus_num:
            extra-=1
        elif outage_group[i] == 0 and outage_buses[i] == 100000000:
            extra -= 1

    # Update Bus Data
    k = 0
    group_size = 1
    new_bus_list = []

    # goes through the list of outage buses
    # For every bus in group 0, a new bus is created
    # For every non-zero group, a new bus is created
    # if load or generation is in the outage_group, they get connected to their associated group
    if extra!=0:
        for i in range(extra):              #only create additional buses equal to extra
            if outage_buses[k] == 100000000 and outage_group[k]==0:
                k+=1
            if outage_group[k] != 0:
                if k!=0:                    #dont check the first element for groupings as it will always start with 0s or if not zeros it will definitely have groupings
                    while outage_group[k] == outage_group[k - 1]:
                        k += 1
                    group_size = outage_group.count(outage_group[k])   #only count group size for groupings and not 0s

            # create new bus with that data
            psspy.bus_data_2(high_bus_num + i + 1,
                             [bus_types[bus_nums.index(outage_buses[k])], bus_areas[bus_nums.index(outage_buses[k])], bus_zones[bus_nums.index(outage_buses[k])],
                              bus_owners[bus_nums.index(outage_buses[k])]], [bus_bases[bus_nums.index(outage_buses[k])], bus_volts[bus_nums.index(outage_buses[k])],
                                                             bus_angs[bus_nums.index(outage_buses[k])]])  # (bus num,[bus type, area num, zone num, own num],[voltage base, volt mag, volt ang])

            #add load/generation to buses
            for t in range(group_size):
                new_bus_list.append([outage_buses[k + t], high_bus_num + i + 1])

                if outage_buses[k+t] ==curr_bus_num:
                    if outage_group[k+t]!=0:        #only transfer the gen from curr_bus_num to new if new_bus for gen is needed
                        psspy.plant_data(high_bus_num+i+1)
                        psspy.machine_data_2(high_bus_num+i+1, '1', [gen_status[index]],[gen_pg[index],gen_qg[index], gen_qmax[index],gen_qmin[index],gen_pmax[index],gen_pmin[index], gen_bases[index],gen_zr[index], gen_zx[index]])                  # busnum,bus id,[status,first owner,second owner, third owner, fourth owner, wind machine limits],[PG,QG,Q up lim, Q low lim, P up lim, P low lim, MBase, ZR,ZX,RT,XT,GTAP,F1,F2,F3,F4,WPF]
                    psspy.machine_data_2(outage_buses[k + t], '1', [0])
                if outage_buses[k+t]==100000000 :
                    if outage_group[k + t] != 0:        #only transfer the load from curr_bus_num to new if new_bus for load is needed
                        psspy.load_data_3(high_bus_num + i + 1, '1', [load_status[index2], load_areas[index2],
                                                                      load_zones[index2], load_owners[index2],
                                                                      load_scale[index2]],
                                          [load_p[index2], load_q[index2], load_ip[index2],
                                           load_iq[index2], load_yp[index2], load_yq[index2]])
                    psspy.load_data_3(curr_bus_num, '1', [0,1,1,1,1])
            k += 1


    else:
        print"No new bus created"

        for i in range(total):
            if outage_group[i] == 0 and outage_buses[i] == curr_bus_num:        #remove gen and load as necessary
                psspy.machine_data_2(curr_bus_num, '1', [0])
            elif outage_group[i] == 0 and outage_buses[i] == 100000000:
                psspy.load_data_3(curr_bus_num, '1', [0,1,1,1,1])



    # Update Line Data
    # For each case of curr_bus_num and the list of lines(as either source/destination bus)
    # if the bus it is connected to is in the outage_group(disconnected)
    # reconnects that other bus to a new bus corresponding to its outage group
    # e.g. all buses in outage group 2 get connected to a newly created bus associated with outage group 2
    for i in range(L_lines):
        if source_lines[i] == curr_bus_num:
            for k in range(total):
                if dest_lines[i] == outage_buses[k]:
                    for l in range(len(new_bus_list)):
                        if new_bus_list[l][0] == outage_buses[k]:
                            psspy.branch_data(source_lines[i], dest_lines[i], '1', [0])
                            psspy.branch_data(new_bus_list[l][1], dest_lines[i], '1', [1],
                                              [line_r[i], line_x[i], line_charging[i], 0, 0, 0, 0, 0, 0, 0,
                                               line_lengths[i], 1, 1, 1,
                                               1])  # from, to, id, [status,metbus,o1,o2,o3,o4],[R,X,B,RateA,RateB,RateC,GI,BI,GJ,BJ,LEN,F1,F2,F3,F4]
        elif dest_lines[i] == curr_bus_num:
            for k in range(total):
                if source_lines[i] == outage_buses[k]:
                    for l in range(len(new_bus_list)):
                        if new_bus_list[l][0] == outage_buses[k]:
                            psspy.branch_data(source_lines[i], dest_lines[i], '1', [0])
                            psspy.branch_data(source_lines[i], new_bus_list[l][1], '1', [1],
                                              [line_r[i], line_x[i], line_charging[i], 0, 0, 0, 0, 0, 0, 0,
                                               line_lengths[i], 1, 1, 1, 1])

    # Update Transformer Data
    # Follows same algorithm as updating the line data
    for i in range(L_txes):
        if source_txes[i] == curr_bus_num:
            for k in range(total):
                if dest_lines[i] == outage_buses[k]:
                    for l in range(len(new_bus_list)):
                        if new_bus_list[l][0] == outage_buses[k]:
                            psspy.two_winding_data_3(source_txes[i], dest_txes[i], '1', [0])
                            psspy.two_winding_data_3(new_bus_list[l][1], dest_txes[i], '1', [1],
                                                     [tx_r[i], tx_x[i], tx_sbase1[i], tx_ratio1[i], tx_nomv1[i], 0,
                                                      tx_ratio2[i], tx_nomv2[i], tx_ratea[i], tx_rateb[i], tx_ratec[i],
                                                      1, 1, 1, 1, 0, 0, 1.1, .9, 1.1, .9, 0, 0, 0])
        elif dest_txes[i] == curr_bus_num:
            for k in range(total):
                if source_txes[i] == outage_buses[k]:
                    for l in range(len(new_bus_list)):
                        if new_bus_list[l][0] == outage_buses[k]:
                            psspy.two_winding_data_3(source_txes[i], dest_txes[i], '1', [0])
                            psspy.two_winding_data_3(source_txes[i], new_bus_list[l][1], '1', [1],
                                                     [tx_r[i], tx_x[i], tx_sbase1[i], tx_ratio1[i], tx_nomv1[i], 0,
                                                      tx_ratio2[i], tx_nomv2[i], tx_ratea[i], tx_rateb[i], tx_ratec[i],
                                                      1, 1, 1, 1, 0, 0, 1.1, .9, 1.1, .9, 0, 0, 0])

    return extra