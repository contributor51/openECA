temp = csvread('mycsv.csv');

count=1;
for i=1:size(temp,1)
    if(temp(i)<=15)
        new(count)=temp(i);
        count=count+1;
    end
end

hist(new,10000)
xlim([-.1 2])
xlabel('Angle Difference')
ylabel('Number of Occurrences')
title('Voltage Angle Difference Distribution')
scatter(