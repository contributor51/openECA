bus_matrix = psspy.abusint(-1, 1, ['NUMBER', 'type', 'area', 'zone', 'owner'])
                        bus_nums = bus_matrix[1][0]
                        bus_types = bus_matrix[1][1]
                        bus_areas = bus_matrix[1][2]
                        bus_zones = bus_matrix[1][3]
                        bus_owners = bus_matrix[1][4]
                        bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angle'])
                        bus_bases = bus_volt_matrix[1][0]
                        bus_volts = bus_volt_matrix[1][1]
                        bus_angs = bus_volt_matrix[1][2]

                        # branch data
                        ierr, Fromline = psspy.abrnint(string='FROMNUMBER')
                        ierr, Toline = psspy.abrnint(string='TONUMBER')

                        temp = psspy.abrnreal(-1, 1, 1, 2, 1, ['length', 'charging'])
                        line_lengths = temp[1][0]
                        line_charging = temp[1][1]
                        temp = psspy.abrncplx(-1, 1, 1, 2, 1, 'rx')

                        line_r = np.real(temp[1][0])
                        line_x = np.imag(temp[1][0])

                        # tx data
                        ierr, Fromtx = psspy.atrnint(string='FROMNUMBER')
                        ierr, Totx = psspy.atrnint(string='TONUMBER')
                        temp = psspy.atrnreal(-1, 1, 1, 1, 1,
                                              ['ratea', 'rateb', 'ratec', 'nomv1', 'nomv2', 'sbase1', 'ratio',
                                               'ratio2'])
                        tx_ratea = temp[1][0]
                        tx_rateb = temp[1][1]
                        tx_ratec = temp[1][2]
                        tx_nomv1 = temp[1][3]
                        tx_nomv2 = temp[1][4]
                        tx_sbase1 = temp[1][5]
                        tx_ratio1 = temp[1][6]
                        tx_ratio2 = temp[1][7]
                        temp = psspy.atrncplx(-1, 1, 1, 1, 1, 'rxact')
                        tx_r = np.real(temp[1][0])
                        tx_x = np.imag(temp[1][0])

                        # get plant/gen data
                        temp = psspy.agenbusint(-1, 1, ['number', 'ireg'])
                        plant_nums = temp[1][0]
                        plant_ireg = temp[1][1]
                        temp = psspy.agenbusreal(-1, 1, ['vspu', 'rmpct'])
                        plant_vs = temp[1][0]
                        plant_rmpct = temp[1][1]
                        temp = psspy.amachint(-1, 4, ['number', 'status'])
                        gen_nums = temp[1][0]
                        gen_status = temp[1][1]
                        temp = psspy.amachreal(-1, 4, ['mbase', 'pgen', 'qgen', 'pmax', 'pmin', 'qmax', 'qmin'])
                        gen_bases = temp[1][0]
                        gen_pg = temp[1][1]
                        gen_qg = temp[1][2]
                        gen_pmax = temp[1][3]
                        gen_pmin = temp[1][4]
                        gen_qmax = temp[1][5]
                        gen_qmin = temp[1][6]
                        temp = psspy.amachcplx(-1, 4, 'zsorce')
                        gen_zr = np.real(temp[1][0])
                        gen_zx = np.imag(temp[1][0])

                        # get load data
                        temp = psspy.aloadint(-1, 1, ['number', 'type', 'area', 'zone', 'owner', 'status', 'scale'])
                        load_nums = temp[1][0]
                        load_types = temp[1][1]
                        load_areas = temp[1][2]
                        load_zones = temp[1][3]
                        load_owners = temp[1][4]
                        load_status = temp[1][5]
                        load_scale = temp[1][6]
                        temp = psspy.aloadcplx(-1, 1, ['mvaact', 'ilact', 'ylact'])
                        load_p = np.real(temp[1][0])
                        load_q = np.imag(temp[1][0])
                        load_ip = np.real(temp[1][1])
                        load_iq = np.imag(temp[1][1])
                        load_yp = np.real(temp[1][2])
                        load_yq = np.imag(temp[1][2])

                        # creates a list of all source buses of lines(inlcudes xformers)
                        temp = psspy.abrnint(-1, 1, 1, 1, 1, 'FromNUMBER')  # branches
                        source_lines = temp[1][0]
                        temp = psspy.abrnint(-1, 1, 1, 5, 1, 'FROMNUMBER')  # 2 winding xformer
                        source_txes = temp[1][0]

                        # creates a list of all destination buses of lines(inlcudes xformers)
                        temp = psspy.abrnint(-1, 1, 1, 1, 1, 'ToNUMBER')  # branches
                        dest_lines = temp[1][0]
                        temp = psspy.abrnint(-1, 1, 1, 5, 1, 'ToNUMBER')  # 2 winding xformer
                        dest_txes = temp[1][0]


#Replace the code below by PSSE API
                        ###############################################################################################
                        type = Bus_info[2]
                        V_mag = Bus_info[3]  # Initial Bus Voltage Magnitudes.(all these data taken inside contingency loop due to following criterion)
                        base_mva = 100
                        PGi = (1 / base_mva) * Bus_info[5]  # PGi, Real Power generated at the buses.
                        QGi = (1 / base_mva) * Bus_info[6]  # QGi, Reactive Power generated at the buses.
                        PLi = (1 / base_mva) * Bus_info[7]  # PLi, Real Power Drawn from the buses.
                        QLi = (1 / base_mva) * Bus_info[8]  # QLi, Reactive Power Drawn from the buses.
                        P_net = PGi - PLi  # Net injected Real Power at the buses.
                        Q_net = QGi - QLi  # Net injected Reactive Power at the buses.
                        num = max(Bus_info[1])
                        ################################################################################################

#testing to add bus data
psspy.bus_data_2(high_bus_num + i + 1,
                 [1, bus_areas[bus_areas.index(outage_buses[k])], bus_zones[bus_zones.index(outage_buses[k])],
                  bus_owners[bus_owners.index(outage_buses[k])]],
                 [bus_bases[bus_bases.index(outage_buses[k])], bus_volts[bus_volts.index(outage_buses[k])],
                  bus_angs[bus_zones.index(outage_buses[
                                               k])]])  # (bus num,[bus type, area num, zone num, own num],[voltage base, volt mag, volt ang])
