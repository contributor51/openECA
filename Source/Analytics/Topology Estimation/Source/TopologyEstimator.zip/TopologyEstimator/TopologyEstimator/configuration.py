#---------------------------------------------------------------------------------------------------------------------
#configuration_matrix = Configuration(contingency)
# Version 1.0(Alpha)
# Last Modified: 11/8/2016

# The purpose of this function is to create all possible configurations of the disconnected elements or circuits
# (branch,Gen,loads) which were initially attached to our current substation.Now the original configuration list
# would have been simply the list as provided by the truth_table fucntion.But as the disconnected(from the substation)
# circuits or elements can be regrouped among each other we have to cater all the possibilities for our study and
# thus come up with a generic yet comprehensive Delta threshold.This function is to generate all those possible
# configurations (much greater than simply 2^contingency).

#Input:
    #contingency:total number of elements/circuits associated with the substation under study
#Output:
    #configuration_matrix:The final list of all possible configurations with different groupings.
    #1's -Connected, 0's -completely isolated and separated, any other number-disconnected from main substation but grouped.
#---------------------------------------------------------------------------------------------------------------------
import pdb,copy
from Truthtable import truth_table
def Configuration(contingency):
    contingency_matrix = truth_table(contingency)               # calling main initial configuration for the first time
    confg = copy.deepcopy(contingency_matrix)
    factor = 2                                                  #initialize the grouping number
    statusfinal = copy.deepcopy(contingency_matrix)             #keep a copy of contingency matrix
    var = len(statusfinal)            #this variable 'var' keeps changing depending upon length of status final matrix
    t2 = var
    alpha = 1

    #Start modifying the initial contingency _matrix
    while alpha ==1:                        #till breaking condition is satisfied
        statusfinal1 = []
        for i in range(0,t2):                     # for all possible cases which changes with each loop
            status_provided = statusfinal[i]      # takes a particular entry of configuration from statusfinal which keeps changing
            zero_index = []                       # position of zeros
            nonzero_index = []                    # position of non -zeros
            nonzero_value = []                    # if non zeros what is the value
            status_append = []
            initial_zeros = status_provided.count(0)     #calculate total number of zeros initially in the given entry
            if initial_zeros > 1 and initial_zeros < 7:   #check and do the following for only entries with --greater than 1 zeros and less than max zeros
                for m in range(0,contingency):
                    if status_provided[m] == 0:
                        zero_index.append(m)                                 #get position of zero bus
                    else:
                        nonzero_index.append(m)                                 #get position of nonzero bus
                        nonzero_value.append(status_provided[m])
                total_zero = len(zero_index)                                #get number of total zero bus
                total_nonzero = len(nonzero_index)                          #%get number of total zero bus
                status_append1=[]
                tempo=truth_table(total_zero)
                for i in range(0,2**total_zero):
                    status_append1.append([x * factor for x in (tempo[i])]) #create new status matrix using modified factor and truth_table
                for temp in range(0,2 ** total_zero):
                    if  len([x for x in status_append1[temp] if x > 0]) > 1:  #only append those columns which have more than one non zero
                        status_append.append( status_append1[temp])           #because if not then multiple redundancies
                columns = len(status_append)               #introduce this colummns variable which will be indicator of how many columns to be appended further
                statusappendtemp=copy.deepcopy(status_append)
                for i0 in range(0, total_nonzero):
                    for i1 in range(0, columns):                                          #dont take last entry as it is already present in confg
                        statusappendtemp[i1].insert(nonzero_index[i0], nonzero_value[i0]) #update the nonzeros value in the appended entries

                #After getting the statusappendtemp matrix(i.e.the new entries,join with statusfinal1)
                statusfinal1.extend(statusappendtemp)

        factor = factor+1           #increment the factor or grouping number
        statusfinal = copy.deepcopy(statusfinal1)            #the purpose of this statusfinal1 is acting like a temporary intermediate variable
        confg .extend(statusfinal)
        criteria=0
        for i9 in range(0,len(statusfinal)):
            criteria=criteria+statusfinal[i9].count(0)
        if criteria != 0:
            t2 = len(statusfinal)                    # to know total coloumns of statusfinal as it is now a combo of various statusfinal1
        else:
            break                                    # break from while loop if no more zeros to be found

        # check if no of zeros in each entry of statusfinal >2 so that we may proceed back to while loop again
        #because no.of zeros >=3 would include all the configurations (even including no.of zeros<=2).
        for i4 in range(0,t2):
            if statusfinal[i4].count(0) <=2:
                alpha = 0
            else:
                alpha = 1

    configuration_matrix = copy.deepcopy(confg)
    length=len(configuration_matrix)
    return configuration_matrix