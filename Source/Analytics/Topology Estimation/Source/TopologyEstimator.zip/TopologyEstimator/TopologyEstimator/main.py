import os,sys
import csv
installPath = os.path.dirname(os.getcwd())
Library = os.path.dirname(installPath) + '\\Library'
#------------------------------------------------------------------------------#
# NEEDED PATH APPENDICES					               #
#------------------------------------------------------------------------------#
sys.path.append(Library)
pssebindir = "C:\Program Files (x86)\PTI\PSSE32\\PSSBIN"
os.environ['PATH'] = pssebindir + ';' + os.environ['PATH']
sys.path.insert(0,pssebindir)
#------------------------------------------------------------------------------#
# MODULES       						               #
#------------------------------------------------------------------------------#
import psspy, numpy as np
import operator, pdb

#Sav = '2019SUM_2013Series_Final_ds.sav'
Sav = 'ieee118bus_PSSEcorrected_rq.sav'
#Sav = 'IEEE14bus.sav'

#------------------------------------------------------------------------------#
# USER PATHS								       #
#------------------------------------------------------------------------------#
PathSav = installPath + '\\TopologyEstimator'	    # Path for .sav


#------------------------------------------------------------------------------#
# MAIN PROGRAM      						               #
#------------------------------------------------------------------------------#
import redirect
redirect.psse2py()
psspy.psseinit(2000000)
psspy.case(PathSav+'\\'+Sav)
sid = 1
from Bus_Connections import bus_connections
from Update_Network import update_network
from configuration import Configuration
#######################################################################################################################
#----------------------------------------------------------------------------------------------------------------------
#main function inside which we first start the analysis of delta threshold from a particular bus number to the
# desired bus number.At each bus number we find the number of circuits/elements connected by calling the bus_connections
#function and then calculate all the possible configurations of disconnection combinations possible  bu calling
# the configuration_matrix function.Then for each element in the configuration_matrix list (i.e. each possible combination)
# we calculate the outage buses and their groupings which is the outage_matrix list and then we update the network by
# rearranging the loads/Generators/Lines/2 winding Txes as required ,crating an additional fake bus as required.
# This is achieved by calling the update_network function.Finally load flow is rum for each case and Difference in angles
#and V_mag is calculated between the current bus number and the disconnected fake bus,thus leading to the study of a
# suitable Delta threshold which can guarantee minimum number of failed cases based on this methodology.
#----------------------------------------------------------------------------------------------------------------------

def main():

    bus_matrix = psspy.abusint(-1, 1, ['NUMBER', 'type', 'area', 'zone', 'owner'])      #call the Bus info for the first time
    bus_nums = bus_matrix[1][0]
    Max_initial_busnum = max(bus_nums)


    # initializing the variables for Delta Angles and Delta V_Mag above and below threshold values
    Y_vector1_Ang = []  # list of Delta Angles above Delta Threshold
    Y_vector2_Ang = []  # list of Delta Angles below Delta Threshold
    Y_vector1_Mag = []  # list of Delta V_Mag above Delta Threshold(outliers)
    Y_vector2_Mag = []  # list of Delta V_Mag below Delta Threshold(outliers)
    final_vector_Ang=[]
    final_vector_Mag=[]
    cases_below = 0                 #cases which pass the test
    cases_up = 0                    #cases which fail the test
    total_cases = 0                 # to know total number of cases
    diverge = 0
    lengthtotal = 0
    indication = []

    # If we want to run the study for some specific range of buses:
    # for i in range(bus_nums.index(313801),bus_nums.index(315294)): #between two specific buses

    # Else if we want to run the analysis for the whole range of the buses
    for i in range(len(bus_nums)):#(len(bus_nums)):  # For Every Bus
        select = bus_nums[i]
        psspy.case(PathSav + '\\' + Sav)  # Reload the original case after each modification and analysis.

        # To know what circuits are connected as well its total number
        num_connec, circ = bus_connections(
            select)  # Call bus_connections function to get the total number of circuits at the selected bus.

        # Calling configuration for knowing all the possible configurations of outages adjacent to the substation
        configuration_matrix = Configuration(num_connec)
        lengthtotal = lengthtotal + len(
            configuration_matrix) - 1  # to know the total number of cases we should be studying except the first case with all 1's.

        # Any other number-Disconnected from original Bus
        # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        # Running Load flow analysis for each possible num_connec

        if len(configuration_matrix) > 2:  # because less than equal to 2 means [1] [0] configuration_matrix  and it wont help us in studies.It means bus connected via one element/branch.
            for i in range(len(configuration_matrix)):
                psspy.case(PathSav + '\\' + Sav)
                num_connec, circ = bus_connections(select)
                indicator1 = 0
                indicator2 = 0
                outage_buses = []
                outage_groups = []
                status_provided = configuration_matrix[i]
                for m in range(num_connec):
                    if status_provided[m] != 1:
                        outage_buses.append(circ[m])  # to get only those buses which are disconnected to find how
                        outage_groups.append(
                            status_provided[m])  # many extra buses to be introduced along with their grouping numbers

                outage_matrix = [outage_buses] + [outage_groups]
                if len(outage_buses) != 0:  # to check if any actual contingencies have talen place or everything is the same.
                    index_temp2 = len(outage_buses)

                    extra = update_network(select,outage_matrix)  # Call update_network function to get the modified arrangement.

                    # if the original bus is being tried to be removed
                    if (status_provided[num_connec - 1] == 1 and index_temp2 >= (num_connec - 1)) or (
                                    status_provided[num_connec - 1] == 0 and index_temp2 == num_connec):
                        print('Gen or load at the present bus is getting disconnected from the system')
                        if select != 1:
                            print('No problem')

                        else:
                            print('Access to remove Slack bus denied')
                    ierr = psspy.fnsl()
                    total_cases = total_cases + 1
                    if ierr != 0:
                        diverge += 1            #temporary variable just to check cases with any type of error after load flow.

                    # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    # Checking for Delta coherency and Angle Mismatch vector
                    temp1 = sorted(zip(outage_matrix[1], outage_matrix[0]))     #sort out the outage buses and groups
                    temp2 = [list(t) for t in zip(*temp1)]
                    outage_buses_sort = temp2[1]
                    outage_groups_sort = temp2[0]

                    bus_matrix = psspy.abusint(-1, 1, ['NUMBER', 'type', 'area', 'zone', 'owner'])
                    bus_nums2 = bus_matrix[1][0]
                    bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angled'])
                    bus_bases = bus_volt_matrix[1][0]
                    V = bus_volt_matrix[1][1]
                    Delta = bus_volt_matrix[1][2]  # in degrees

                    if extra != 0:  # to proceed calculation we need to know if there were any new extra buses created or not
                        Diff_Ang = []
                        Difference_Ang = 0
                        Diff_Mag = []
                        Difference_Mag = 0

                        for i in range(extra):

                            if (outage_buses_sort[i] != select) or (outage_buses_sort[i] != 100000000):  # because this means no new buses were created hence no difference to be calculated
                                temp1 = select
                                # temp2=outage_buses_sort(i);
                                if outage_groups_sort[i] != 0:
                                    temp2 = Max_initial_busnum + extra - (max(outage_groups_sort) - outage_groups_sort[i])
                                else:
                                    temp2 = Max_initial_busnum + i + 1
                                Difference_Ang = abs(Delta[bus_nums2.index(temp1)] - Delta[bus_nums2.index(temp2)])
                                Difference_Mag = abs(V[bus_nums2.index(temp1)] - V[bus_nums2.index(temp2)])

                                Diff_Ang.append(Difference_Ang)
                                Diff_Mag.append(Difference_Mag)

                        for i in range(len(Diff_Ang)):
                            if (Diff_Ang[i] >= 0.75) or Diff_Mag[i] > 0.02:  #here to check we have taken a big Delta V_Mag =0.02 pu. and Delta V_ang=0.75 deg to test our percent_success rate.
                                print('Bus ', outage_buses_sort[i], ' and ', select, ' are disconnected')

                                Y_vector1_Ang.append(Diff_Ang[i])
                                Y_vector1_Mag.append(Diff_Mag[i])
                                if indicator2 != 1:             #even if one disconnection leads to faulty results the whole status_provided will be deemed as failed case
                                    indicator1 = 1

                            elif (Diff_Ang[i] < 0.75) and (Diff_Mag[i] <= 0.02):
                                Y_vector2_Ang.append(Diff_Ang[i])
                                Y_vector2_Mag.append(Diff_Mag[i])
                                indicator2 = 1
                                indicator1 = 0
                                indication.append([select, status_provided])    #to check which buses and which configurations associated with those buses have failed.

                else:
                    print('Normal Load Flow and no disconnection')

                if indicator1 == 1:
                    cases_up = cases_up + 1   #increment no.of cases passing the test with predetermined Delta values

                if indicator2 == 1:
                    cases_below = cases_below + 1   #increment no.of cases failing the test with predetermined Delta values
                print"current bus number is", select
                print"status_provided =", status_provided
                print "outage_matrix=", outage_matrix
    actual_total_cases = cases_up + cases_below
    print"cases below", cases_below
    print"cases up", cases_up
    print"total_cases", lengthtotal
    percent_success = 100 * (float(cases_below) / float(lengthtotal))
    print"percent success=", percent_success, "%"
    final_vector_Ang.extend(Y_vector1_Ang)
    final_vector_Ang.extend(Y_vector2_Ang)
    final_vector_Mag.extend(Y_vector1_Mag)
    final_vector_Mag.extend(Y_vector2_Mag)

    csv_out = open("mycsv.csv", 'wb')
    mywriter = csv.writer(csv_out, delimiter='\t', lineterminator='\n')
    for row in zip( final_vector_Ang,final_vector_Mag):
        mywriter.writerow(row)
    csv_out.close()



if __name__ == "__main__":
    main()