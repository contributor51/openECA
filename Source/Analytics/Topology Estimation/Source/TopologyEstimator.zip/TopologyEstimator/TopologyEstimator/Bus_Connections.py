#-----------------------------------------------------------------------------
#(num_connec, connec_list) = bus_connections(curr_bus_num)
# Version 1.0(Alpha)
# Last Modified: 11/8/2016

# The purpose of this function is to calculate the number of objects connected
# to a specific input bus and to determine each of those objects. The output
# will give you a number of connections and a list contained each bus connected.
# Additionally, if the bus has a generator and additional connection of its
# own bus number is added. If there is a load present at the bus, an additional
# connect with the value of 100000000 is added.

#Inputs:
    # curr_bus_num: The bus for which the connection list is desired

#Outputs:
    # num_connec: The number of objects connected to the bus
    # connec_list: The list of specific objects which are connected
#-----------------------------------------------------------------------------

import numpy as np, pdb, psspy
def bus_connections(curr_bus_num):

    # For the input bus, determine the number of connections and which bus is connected to it.
    # Additionally, if there is a load/gen connected(non-bus), count that as a connection and notate it with the current bus number

    # reads the data of the current system

    temp=psspy.aloadint(-1,1,'NUMBER')#load data
    load_data=temp[1][0]
    temp = psspy.amachint(-1, 4, 'NUMBER')# machine/gen data
    gen_data=temp[1][0]

    # branch data to determine all source/destination buses
    temp=psspy.abrnint(-1,1,1,1,1,'FromNUMBER')#branches
    source_buses=temp[1][0]
    temp=psspy.abrnint(-1,1,1,5,1,'FROMNUMBER')#2 winding xformer
    source_buses.extend(temp[1][0])
    temp = psspy.abrnint(-1, 1, 1, 1, 1, 'ToNUMBER')  # branches
    dest_buses = temp[1][0]
    temp = psspy.abrnint(-1, 1, 1, 5, 1, 'ToNUMBER')  # 2 winding xformer
    dest_buses.extend(temp[1][0])


    # determines the number of connections
    # counts the instances of curr_bus_num in the list of lines(both source and destination lines)
    # also adds the instances of curr_bus_num in the generator and load lists
    num_connec = source_buses.count(curr_bus_num)+dest_buses.count(curr_bus_num)+load_data.count(curr_bus_num)+gen_data.count(curr_bus_num)

    # determines which buses are connected to current bus
    connec_list=[]
    source_indices=[i for i,val in enumerate(source_buses) if val == curr_bus_num]
    dest_indices = [i for i, val in enumerate(dest_buses) if val == curr_bus_num]
    load_indices = [i for i, val in enumerate(load_data) if val == curr_bus_num]
    gen_indices = [i for i, val in enumerate(gen_data) if val == curr_bus_num]
    for i in range(len(source_indices)):
        connec_list.append(dest_buses[source_indices[i]])
    for i in range(len(dest_indices)):
        connec_list.append(source_buses[dest_indices[i]])

    # appends additional connections if load/gen are connected to bus
    for i in range(len(load_indices)):
        connec_list.append(100000000)
    for i in range(len(gen_indices)):
        connec_list.append(curr_bus_num)

    #pdb.set_trace()
    return num_connec,connec_list